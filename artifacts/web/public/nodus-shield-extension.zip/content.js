(function(){"use strict";function g(e){return e.trim().replace(/\/+$/,"")}function x(e){const n=[],i=e.sources.filter(s=>s.available);return e.knownThreat&&n.push("This target matches a verified threat in the Nodus database."),e.verdict==="safe"?n.push("No significant threats were detected by the available intelligence sources."):e.verdict==="caution"?n.push("Some risk signals were found. Review the details before connecting your wallet."):n.push("High-risk signals detected. Avoid connecting your wallet or signing transactions."),i.length>0?n.push(`Analyzed by ${i.map(s=>s.source).join(" and ")}.`):n.push("No automated third-party intelligence was available for this target."),e.communityReports>0&&n.push(`${e.communityReports} community report${e.communityReports===1?"":"s"} on file.`),n.join(" ")}const t="nodus-shield-banner",f="nodus-shield-style";function b(){if(document.getElementById(f))return;const e=document.createElement("style");e.id=f,e.textContent=`
    #${t} {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 2147483647;
      display: flex;
      align-items: center;
      gap: 14px;
      padding: 12px 18px;
      background: #dc2626;
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Inter, Roboto, sans-serif;
      font-size: 14px;
      line-height: 1.4;
      box-shadow: 0 6px 24px rgba(0, 0, 0, 0.28);
      animation: nodus-slide-down 0.28s ease-out;
    }
    @keyframes nodus-slide-down {
      from { transform: translateY(-100%); }
      to { transform: translateY(0); }
    }
    #${t} .nodus-mark {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 30px;
      height: 30px;
      border-radius: 8px;
      background: rgba(255, 255, 255, 0.18);
      font-weight: 900;
      flex: 0 0 auto;
    }
    #${t} .nodus-text { flex: 1 1 auto; min-width: 0; }
    #${t} .nodus-title { font-weight: 800; letter-spacing: -0.01em; }
    #${t} .nodus-sub { opacity: 0.92; font-size: 13px; margin-top: 2px; }
    #${t} a.nodus-link {
      color: #fff;
      text-decoration: underline;
      font-weight: 700;
    }
    #${t} .nodus-actions { display: flex; align-items: center; gap: 10px; flex: 0 0 auto; }
    #${t} .nodus-report {
      background: #fff;
      color: #dc2626;
      border: none;
      border-radius: 999px;
      padding: 7px 14px;
      font-weight: 800;
      font-size: 13px;
      cursor: pointer;
    }
    #${t} .nodus-dismiss {
      background: transparent;
      color: #fff;
      border: 1px solid rgba(255, 255, 255, 0.5);
      border-radius: 999px;
      width: 28px;
      height: 28px;
      font-size: 16px;
      line-height: 1;
      cursor: pointer;
    }
  `,document.documentElement.appendChild(e)}function h(e,n){if(document.getElementById(t))return;b();const i=g(n),s=e.target,a=document.createElement("div");a.id=t,a.setAttribute("role","alert");const l=document.createElement("span");l.className="nodus-mark",l.textContent="!";const u=document.createElement("div");u.className="nodus-text";const m=document.createElement("div");m.className="nodus-title",m.textContent=`Nodus Shield: high risk detected (${e.score}/100)`;const d=document.createElement("div");d.className="nodus-sub",d.textContent=x(e);const o=document.createElement("a");o.className="nodus-link",o.href=`${i}/scan`,o.target="_blank",o.rel="noopener noreferrer",o.textContent="View full report",d.append(" ",o),u.append(m,d);const p=document.createElement("div");p.className="nodus-actions";const c=document.createElement("button");c.className="nodus-report",c.textContent="Report threat",c.addEventListener("click",()=>{window.open(`${i}/report?target=${encodeURIComponent(s)}`,"_blank","noopener")});const r=document.createElement("button");r.className="nodus-dismiss",r.title="Dismiss",r.textContent="×",r.addEventListener("click",()=>a.remove()),p.append(c,r),a.append(l,u,p),document.documentElement.appendChild(a)}chrome.runtime.sendMessage({type:"CONTENT_READY"},e=>{chrome.runtime.lastError||!e||e.warn&&e.result&&h(e.result,e.apiBase)}),chrome.runtime.onMessage.addListener(e=>{e?.type==="NODUS_WARN"&&e.payload&&h(e.payload,e.apiBase??"")})})();
